package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {
    	@Valid
	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class Server{
    public static String generateHash(String name)throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
        byte[] myHash = messageDigest.digest(name.getBytes(StandardCharsets.UTF_8));
        BigInteger numberHelper = new BigInteger(1, myHash);  
        StringBuilder hashPadding = new StringBuilder(numberHelper.toString(16));
        for(byte b: myHash){
            hashPadding.append(String.format("%02x", b));
        }
        return hashPadding.toString();
    }
    
    @Size(min=1, max=22)
    @NotBlank
    @GetMapping("/")
    public String getHash() throws NoSuchAlgorithmException{
        String hashedString = "a man a plan a canal panama";
        String actualHash = generateHash(hashedString); 
        return "<h1>Hashed String</h1><p><strong>hashed string:</strong> " + hashedString + " <p>Cipher algorithm used: SHA-512</p>" + "<strong>CheckSum: </strong>" + actualHash;
    }
    
    @Size(min=1, max=22)
    @NotBlank
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
        String hashedString = "a man a plan a canal panama";
        String actualHash = generateHash(hashedString);
        return "<h1>Hashed String</h1><p><strong>hashed string:</strong> " + hashedString + " <p><strong>Cipher algorithm used:</strong> SHA-512</p>" + "<strong>CheckSum: </strong>" + actualHash;
    }
}

@Configuration
@EnableWebSecurity
class WebSecurityConfig extends WebSecurityConfigurerAdapter{
    @Size(min=1, max=22)
    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/hash");
    }
}